/*Global Interface*/

export interface AnyObject {
    [key: string]: any;
}
