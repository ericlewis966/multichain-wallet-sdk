import Wallets from './wallet';

export default  Wallets