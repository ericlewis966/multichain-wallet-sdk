import * as Ethereum from "./ethereum";
import * as Solana from "./solana";

export default {
    Ethereum,
    Solana
};