const config = {
    testTimeout: 500000,
};

module.exports = config;
